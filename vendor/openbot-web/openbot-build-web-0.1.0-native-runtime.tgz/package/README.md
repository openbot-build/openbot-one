# OpenBot UI

The MIT web app for [OpenBot](https://github.com/openbot-build/openbot).
It uses Vite, React Router, shadcn/ui, and Effect Atom.

Install `@openbot-build/client` from GitHub Packages. This repository publishes
`@openbot-build/web` with its static build in `dist`.

See the [package setup and release guide](https://docs.openbot.build/contributing#package-releases)
for registry access, first installation, version tags, and commit versions.
Use `devenv shell -- bash scripts/install.sh`, then `devenv shell -- pnpm dev`.
The dev server sends API calls to `OPENBOT_DEV_PUBLIC_ORIGIN` (default `http://localhost`).
Use `devenv shell -- pnpm client:update <version>` to change the client version.

Run `devenv shell -- direnv allow` once in this folder to let direnv load the
project shell. Zed uses `.zed/settings.json`: Nix runs through `devenv lsp`,
and TypeScript and TSX use the local TypeScript 7 language server. Install the
project packages before opening TypeScript files in Zed.

MIT. See [LICENSE](./LICENSE). Installed packages keep their own licenses.

## Native shell entry

The browser remains the default. A native shell can import
`@openbot-build/web/runtime` and call `installRuntime` before the app entry runs.
The `NativeRuntime` type defines the version 1 boundary. It supplies the HTTPS
API origin, a Fetch-compatible transport, login/logout, Live WebSockets,
clipboard writes, and external URL opening. Keep long-lived credentials in the
native process. The transport must preserve cancellation and streamed responses.
Direct file uploads use `fetchResource`, which selects that native transport or
browser fetch. The shell must check file-storage destinations separately and
keep API credentials out of those requests.
Login resolves only when the new native session can make API calls; the UI then
opens the saved local return path.

`pnpm build` also builds the public runtime module and its types. The static
build contains `openbot-runtime.json`, which tells a shell which runtime version
the UI accepts, and `licenses/dependencies.md`. Ship these files with the assets.
The shell must load its adapter before the UI module. Do not rewrite the bundled
application code or point native requests at the page origin.

An optional `emailSignIn: true` means native fetch can accept the published
email-code login. The shared form uses the same typed client and error messages
as the browser. The shell must capture the session cookie only from a successful
`POST /auth/email/verify`, check it through `/auth/session`, and keep it out of
response headers and Web storage. Complete the session before resolving fetch;
the page then reloads with the account's storage namespace. Old shells without
the flag do not offer this flow.

An optional `browserSignIn` action offers company sign-in through the system
browser. The shell owns PKCE, exact callbacks, state and issuer checks, private
session exchange, and account validation. The UI passes only email/invitation
hints and an AbortSignal; no code or credential reaches web scripts. The form
shows a waiting state and Cancel sign-in. The shell must bind preparation and
cancellation to the document, service and a unique operation ID so a late cancel
cannot stop a new attempt. Unsupported shells keep this option hidden.

The optional `session` field gives only persistence/recovery status and a retry
action. It carries no credential. The shell must verify a saved session with
its service before restoring the account. If saving cannot be confirmed, the
shared app shows that another sign-in may be needed after close. Retry either
checks the saved sign-in or finishes its removal. Service selection returns to
the app entry so a remembered account can resume without another email code.

Live capture loads a local `capture-worklet` build asset. It must remain a
separate file in `dist/assets`; strict native CSP does not allow Blob scripts.
Ship that file with the rest of the Web assets. Browser and native capture use
the same worklet and cancellation path.

The shared layout uses CSS safe areas and the visual viewport for the keyboard.
It keeps pinch zoom available and never clears focus on resize. Dialogs and
side sheets use the same visible height as the chat. An optional `onBackPress`
runtime action lets Android close the last open dialog or sheet first. The
shell handles history and root exit when no shared surface consumes Back.

An optional `onAppStateChange` reports mobile activity changes. Live talks end
when the app becomes inactive, the page is hidden, or the chat/organization
changes. Returning to the app never starts a new talk. Pending microphone
grants and worklet setup are canceled; a late grant has its tracks stopped.
The media prompt itself cannot be withdrawn through `getUserMedia`.
