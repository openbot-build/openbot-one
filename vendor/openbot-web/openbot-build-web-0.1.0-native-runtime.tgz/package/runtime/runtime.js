/** Install once, before the shared app starts. This module starts no I/O. */
export function installRuntime(runtime) {
    if (globalThis.__OPENBOT_RUNTIME__ !== undefined)
        throw new Error("The app runtime is already set.");
    if (runtime.version !== 1 || runtime.kind !== "native")
        throw new Error("The app runtime version is not supported.");
    const origin = new URL(normalizeServiceOrigin(runtime.apiOrigin, runtime.development));
    if (origin.origin !== runtime.apiOrigin ||
        origin.username !== "" ||
        origin.password !== "")
        throw new Error("The API needs an HTTPS origin without a path or credentials.");
    for (const name of [
        "fetch", "signIn", "signOut", "writeClipboard", "openExternal", "createWebSocket",
    ])
        if (typeof runtime[name] !== "function")
            throw new Error(`The app runtime has no ${name} action.`);
    if (runtime.browserSignIn !== undefined && typeof runtime.browserSignIn !== "function")
        throw new Error("The browser sign-in action is not valid.");
    Object.defineProperty(globalThis, "__OPENBOT_RUNTIME__", {
        value: Object.freeze({ ...runtime }),
        writable: false,
        configurable: false,
    });
}
/** Browser callers have no native dependency or import-time setup. */
export const nativeRuntime = () => globalThis.__OPENBOT_RUNTIME__;
export const apiOrigin = () => nativeRuntime()?.apiOrigin ?? globalThis.location?.origin ?? "";
/** Native requests use the shell's API and file-storage origin checks. */
export const fetchResource = (input, init) => (nativeRuntime()?.fetch ?? globalThis.fetch)(input, init);
export function storageKey(name) {
    const namespace = nativeRuntime()?.storageNamespace;
    return namespace ? `${namespace}.${name}` : name;
}
/** Only local development can use cleartext HTTP. Native Rust checks it again. */
export function normalizeServiceOrigin(input, development = false) {
    const url = new URL(input.trim());
    const loopback = url.hostname === "localhost" || url.hostname === "[::1]" || /^127\.\d+\.\d+\.\d+$/.test(url.hostname);
    if ((url.protocol !== "https:" && !(development && url.protocol === "http:" && loopback)) || url.username || url.password || url.href !== `${url.origin}/`)
        throw new Error("Use an HTTPS service address without a path. Local HTTP is allowed only during development.");
    return url.origin;
}
export const writeClipboard = (text) => {
    const native = nativeRuntime();
    if (native !== undefined)
        return native.writeClipboard(text);
    if (globalThis.navigator?.clipboard === undefined)
        return Promise.reject(new Error("The clipboard is not available."));
    return globalThis.navigator.clipboard.writeText(text);
};
/** A WebSocket transport can live in Rust; the UI uses its WebSocket surface. */
export const createWebSocket = (url) => nativeRuntime()?.createWebSocket(url) ?? new WebSocket(url);
export function externalUrl(input) {
    const url = new URL(input);
    if (url.protocol !== "https:" || url.username !== "" || url.password !== "")
        throw new Error("This external link is not an HTTPS address.");
    return url.href;
}
/** Return paths can never send a login result to a different origin. */
export function returnPath(input) {
    if (!input?.startsWith("/") || input.startsWith("//") || /[\\\u0000-\u001f]/.test(input))
        return "/";
    const url = new URL(input, "https://return.invalid");
    return url.origin === "https://return.invalid" ? url.pathname + url.search + url.hash : "/";
}
