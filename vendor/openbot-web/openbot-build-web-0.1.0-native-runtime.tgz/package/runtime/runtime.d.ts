/** The public boundary between the shared Web app and a native shell. */
export interface NativeRuntime {
    readonly version: 1;
    readonly kind: "native";
    readonly apiOrigin: string;
    readonly development?: boolean;
    readonly developmentSignIn?: boolean;
    /** Native fetch accepts the email-code session and keeps its cookie private. */
    readonly emailSignIn?: boolean;
    readonly session?: {
        readonly persistence: "none" | "saved" | "memory";
        readonly issue?: "browser-sign-in-incomplete" | "store-unavailable" | "service-unavailable" | "invalid-saved-sign-in" | "not-saved" | "cleanup-pending" | "sign-out-incomplete";
        readonly retry: () => Promise<void>;
    };
    readonly storageNamespace?: string;
    readonly connection?: {
        readonly defaultOrigin: string;
        /** Block normal app setup until the user repairs or re-reads settings. */
        readonly recovery?: "invalid-settings" | "unsupported-version" | "unreadable-settings";
        readonly retry?: () => Promise<void>;
        /** Save the selection, cancel old requests, then reload the app. */
        readonly change: (origin: string | null) => Promise<void>;
    };
    /** Fetch keeps native credentials in the shell and supports abort and streams. */
    readonly fetch: typeof globalThis.fetch;
    /** Resolve only after the new native session is ready for API calls. */
    readonly signIn: (input: {
        readonly email?: string;
        readonly returnTo?: string;
        readonly invitation?: string;
    }) => Promise<void>;
    /** The shell opens the system browser and owns all grant values. */
    readonly browserSignIn?: (input: {
        readonly email?: string;
        readonly invitation?: string;
        readonly returnTo?: string;
        readonly signal?: AbortSignal;
    }) => Promise<void>;
    readonly signOut: () => Promise<void>;
    readonly writeClipboard: (text: string) => Promise<void>;
    readonly openExternal: (url: string) => Promise<void>;
    readonly createWebSocket: (url: string) => WebSocket;
    /** Return true to consume Android back, before native history or app exit. */
    readonly onBackPress?: (handler: () => boolean) => Promise<() => void>;
    /** Mobile OS activity changes. Resuming never starts a new talk by itself. */
    readonly onAppStateChange?: (handler: (state: "active" | "inactive") => void) => Promise<() => void>;
}
declare global {
    var __OPENBOT_RUNTIME__: NativeRuntime | undefined;
}
/** Install once, before the shared app starts. This module starts no I/O. */
export declare function installRuntime(runtime: NativeRuntime): void;
/** Browser callers have no native dependency or import-time setup. */
export declare const nativeRuntime: () => NativeRuntime | undefined;
export declare const apiOrigin: () => string;
/** Native requests use the shell's API and file-storage origin checks. */
export declare const fetchResource: typeof globalThis.fetch;
export declare function storageKey(name: string): string;
/** Only local development can use cleartext HTTP. Native Rust checks it again. */
export declare function normalizeServiceOrigin(input: string, development?: boolean): string;
export declare const writeClipboard: (text: string) => Promise<void>;
/** A WebSocket transport can live in Rust; the UI uses its WebSocket surface. */
export declare const createWebSocket: (url: string) => WebSocket;
export declare function externalUrl(input: string): string;
/** Return paths can never send a login result to a different origin. */
export declare function returnPath(input: string | null | undefined): string;
